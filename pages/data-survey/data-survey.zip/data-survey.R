# library
library(likert) 
library(openxlsx)


dat <- read.xlsx('EDITED-data-survey-data.xlsx',
                 sheet = 3)
dat <- dat[,c(2,5,6,7,8,11)]
dat[,1] <- factor(dat[,1])
dat[,2] <- factor(dat[,2])
dat[,3] <- factor(dat[,3])
dat[,4] <- factor(dat[,4])

names(dat)[1] <- 'Q1 Aware of data resources'
names(dat)[2] <- 'Q2a Data use: Teaching'
names(dat)[3] <- 'Q2b Data use: Research'
names(dat)[4] <- 'Q2c Data use: Other'


p0 <- likert(dat[,1:4])
plot(p0)


dat[,5] <- factor(dat[,5], levels = c('No', 'Maybe', 'Yes'),
                                      ordered = T)
dat[,6] <- factor(dat[,6], levels = c('No', 'Maybe', 'Yes'),
                                      ordered = T)

names(dat)[5] <- 'Q3 Specfic data storage needs'
names(dat)[6] <- 'Q4 Satisfied with data resources'

p1 <- likert(dat[,5:6])
plot(p1)

chisq.test(table(dat[,1]))
chisq.test(table(dat[,2]))
chisq.test(table(dat[,3]))
chisq.test(table(dat[,4]))

chisq.test(table(dat[,5]))
chisq.test(table(dat[,6]))



# Use a provided dataset
data(pisaitems) 
items28 <- pisaitems[, substr(names(pisaitems), 1, 5) == "ST24Q"] 

# Build plot
p <- likert(items28) 
plot(p)


